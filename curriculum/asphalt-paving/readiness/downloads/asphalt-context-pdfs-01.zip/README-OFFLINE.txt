Asphalt source PDFs · volume 01 of 07

Extract this ZIP into its own folder and open index.html. PDF parts and text open locally. Publisher links require internet. Page ranges are original source PDF viewer pages, not printed page labels. All original publication notices are retained. Model/edition applicability still needs verification. Other volumes contain the rest of the collection; consult the repository downloads page for checksums and ranges.
