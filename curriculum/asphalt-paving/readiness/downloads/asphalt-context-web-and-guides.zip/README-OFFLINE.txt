ACCESS IS4S asphalt tools, safety and preparation

Open field-guide.html for the illustrated route, tools.html for all equipment groups, coverage.html for all 68 competencies, gaps.html for remaining provider requirements, or index.html for the catalogue. Regulatory articles and their figures are included locally. Links to source PDF parts and other curriculum collections open GitHub; use the separate PDF ZIP volumes for offline PDFs. Raw publisher HTML is preserved as inert .txt. Technical dates and model limits remain part of each record.
