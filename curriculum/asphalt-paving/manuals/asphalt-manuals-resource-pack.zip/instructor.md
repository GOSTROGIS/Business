# Manual-reading lesson · Teaching and answer guidance

## Prepare a complete document-reading session

Allow about 90–120 minutes for MAN-01–09, or divide that sequence into two sessions. Add about 45–60 minutes for VIS-01–04, with more time when needed for the full-size figures and actual device turns. These are proposed ACCESS classroom practice times, not official technical-training allocations. Prepare the six original OEM PDFs, the original Deere HTML manual, their covers/contents for print access, a PDF reader, a writable practice folder and the fictional records. Do not place machines in this activity. Arrange actual device turns if Digital is an intended observation. Confirm that all learners can reach a useful view and that practice IDs carry no private data. Model page navigation using a different heading before assigning MAN-02. The Deere HTML contents and local images/styles work without an internet connection.

The lesson teaches source selection, document navigation and a bounded handover. It does not award an equipment endorsement or demonstrate maintenance performance. Cover matching is necessary evidence for document selection; it does not establish every detail of actual-machine applicability. The manuals include original technical instructions, but the lesson assesses finding and interpreting information, not carrying those procedures out.

Use agreed access tools and record exact solving prompts separately. A learner can use text-to-speech and still independently decide which serial statement applies. If the observer supplies the matching manual, that decision has been supported. A missing device turn is Not observed for Digital, not an inferred failure. Invite another attempt with changed fictional data after feedback.

## Teach the visual vocabulary

Begin with the whole view, then a callout and its exact name. Model one sentence joining **number + term + function**. Ask learners to explain the remaining terms in their own words. Pointing alone may show a location; it does not yet demonstrate understanding of a function. Allow speech, signing, text or an agreed communication aid, and preserve the learner's own decision.

Open the larger PNG or the source PDF when a callout is too small. Describe the part's position and supply the accessible name table, without selecting the learner's answer. For the dimension page, keep both the diagram and its table visible. Read letters and units aloud when useful. Do not infer a practical skill or assign an official Skills for Success proficiency level from these classroom checks.

The images are faithful page-region crops. Their figure notes use APA-style source credits, and the lesson's reference list provides the full publication details. Source files, publication dates and serial scopes remain distinct. No MS-4 figure is claimed in this lesson: the pictured sources are the three identified OEM manuals.

### Relationship to the trade outline

The following locators refer to the supplied *Asphalt Paving/Laydown Technician Program Outline* file dated August 2016 in its filename. Use the exact learning-task scope below. This lesson supplies introductory reading and vocabulary practice, not complete technical coverage of I2, J1 or L1.

| Visual practice | SkilledTradesBC competency and learning task | Outline PDF / printed page | Evidence produced here / remaining scope |
|---|---|---|---|
| VIS-01 | A1.1, “Describe paving and what types of equipment are used”; I2.2, “Describe major components” | 22 / 20; 72 / 70 | Four component names and explained functions; I2's other machine categories and attachments remain separate instruction. |
| VIS-01–02 | J1.2, “Describe common attachments”; J1.3, “Describe principal functions” | 84 / 82 | Screed extension and end-gate vocabulary plus the route of material to the screed. Screed categories, the full attachment set, adjustments and timing are not assessed. J2 concerns safety/job planning and is not the component-identification code. |
| VIS-02 | A1.1; preparatory context for A3, “Describe paving technology” | 22 / 20; 24 / 22 | Material-route explanation. The four-card route does not cover A3's two plant types, ingredients, resources, liquids or recycling requirements. |
| VIS-03 | L1.1, “Describe types of Compaction Rollers”; L1.2, “Describe major components of compaction equipment” | 95 / 93 | Reads one identified tandem-drum example and distinguishes component type from action. L1's complete selection criteria and compaction-train functions remain to be taught. |
| VIS-04 | Supporting document and numeracy practice for equipment descriptions | 95 / 93, L1.1 includes drum widths and weight | Reads published whole-machine dimensions, not drum width or weight; do not substitute this task for that specific L1 content. |

The outline's category words and an actual manual's model-specific information can differ in detail. In VIS-03, the source model uses gasoline. Preserve the correct model-specific wording rather than teaching the outline's “diesel powered” bullet as a universal statement about every roller. A diagram or rounded dimension is not an approved machine-selection or site-clearance decision.

### Visual-practice answer guidance

| Activity | Expected evidence and useful check |
|---|---|
| VIS-01 | 7 **Hopper** receives/holds delivered mixture; 10 **Screed Extension** relates to working width; 11 **End Gate** helps form the paving edge; 12 **High-Speed Rubber Tracks** provide the tractor's ground-contact/traction system. Require a correct source callout and sensible function for each, then an actual listener check-back. Do not require the source's promotional comparisons or machine settings. |
| VIS-02 | **Hopper → conveyors → augers → screed** is the conceptual material route. Conveyors move mixture rearward; augers distribute it across towards the screed. The draft hopper claim should be corrected: the hopper receives/holds mixture; the screed shapes and initially compacts the placed layer, with subsequent rolling addressed separately. Retain the actual partner trial and reasoned change/retention. A diagram arrow does not identify a safe personnel route. |
| VIS-03 | The selected source names are 6 Rear Roller, 16 Hourmeter, 17 Water Tank, 19 Operator's Seat, 21 Seat Belt and 25 Documentation Box. Diagram: Figure 4 on PDF/printed page 14; descriptions: page 15. Cover: Honda GX630RQZB2 **gasoline** engine; page 12 identifies a Honda GX630 gasoline engine. Accept a corrected label naming the AR13HA/AR13HAR model and gasoline power. Observe actual navigation, saved version and swapped finder/checker roles before recording Digital, Adaptability or Collaboration evidence. |
| VIS-04.1 | F = **692 mm**; G = **346 mm**. 2 × 346 mm = 692 mm, matching the published width F. Require locating the dimension letters on the upper view as well as reading the rows. |
| VIS-04.2 | 692 mm ÷ 1,000 = **0.692 m**. 692 m is one thousand times the stated dimension, so retaining the unchanged number while changing the unit is an error. |
| VIS-04.3 | H = 1,990 mm; I = 1,170 mm; H − I = **820 mm**. This is a comparison of the two labelled dimensions, not a new manufacturer operating limit. |
| VIS-04.4 | 700 mm − 692 mm = **8 mm total nominal difference**. Do not call it safe clearance, or assign half to each side without an explicit centring assumption. The doorway value is fictional; orientation, actual dimensions/configuration, route and safe-movement requirements are not supplied. |

**Fresh visual check.** Ask the learner to find callout **3** and **9** in Figure 1 (Beacon Light; Foldable Walkboard), then locate **B** and **F** in Figure 4 (1,470 mm; 692 mm). Compare 1.470 m and 0.692 m only after showing the letter-to-row route. A correct memorized number without the matching dimension is incomplete evidence of document reading.

## Answer guidance for MAN-01–09

| Activity | Expected evidence and common errors |
|---|---|
| MAN-01 | OEM-01: LeeBoy 8680, 1033428-SOP, serial 365152 and above; cover does not independently print a revision. REV A comes from the manufacturer filename, while 2026 is the copyright year. OEM-02: MRH800GS Revision 10, 11 June 2020, listed GX390 engine variants; no cover serial range. OEM-03: AR13HA/AR13HAR Revision 1, 18 June 2021, 110301 and above, GX630RQZB2. OEM-04: same model family Revision 10, 25 June 2021, 100901 and below, GX610K1QZB2/GX610R1QZB2. OEM-05: Cat C3.6/C2.8 engines, M0108394-08, July 2022, J37/J29 1-UP engine scope. OEM-06: Cat fluids special publication SEBU6250-30, December 2020; cover scope reads “All Machines 87A 1-UP (Machine)”; preserve that wording but do not apply it universally to other brands. OEM-07: Deere 410G, OMT166701 D1, original copyright 2000; no title/front-matter serial range found. |
| MAN-02 | LeeBoy Contact Information is PDF page 25, printed 2-3. It identifies model/serial information on the machine nameplate and directs readers to the engine manual for its nameplate. Observe open/find/save/close/reopen and the second navigation method. A correct paper locator does not demonstrate those digital actions. Deere’s identification destination is titled Record Engine Serial Number, local file `05T_120_J3_19_13JUL00_1.htm`; it is an HTML section, not PDF page 25. |
| MAN-03 | Maintenance ranges each include 10 pages: 32 − 23 + 1 = 10 and 34 − 25 + 1 = 10. Complete-file difference: 46 − 42 = 4 pages. Neither determines training time or equivalence. The uncovered integer serial interval is 100902–110300 inclusive, containing 110300 − 100902 + 1 = 9,399 possible values. These are numbers between cover boundaries, not evidence that 9,399 machines exist. |
| MAN-04 | Record A's stated serial 110450 falls within OEM-03's printed range; record B's 100850 falls within OEM-04's range; record C's 105500 matches neither supplied range. The later date/higher revision of OEM-04 does not erase its serial restriction. Require the next confirmation action and limits, not exact model wording. The learner adds this decision note to v1 while retaining the earlier navigation note. |
| MAN-05 | Response 3 preserves the unresolved selection. Known facts include model and stated serial; missing evidence can include complete/configuration identification and manufacturer confirmation of the applicable/current manual. Neither numerical proximity nor revision rank is a selection rule. The draft request may ask the responsible person to confirm the machine record and obtain the applicable publication. No actual reply should be invented. |
| MAN-06 | Listener's check-back preserves model, unresolved range and next step for C. For A, it preserves the cover match and remaining current/configuration/authorization checks. Record actual listener meaning, questions and speaker response. An accurate first reading can be verified without inventing a repair. |
| MAN-07 | Roles actually swap; each learner contributes a cover reading and a navigation check across the two documents. OEM-01 is paver scope; OEM-02 is walk-behind roller scope. Keep who checked what and the agreed sharing boundary. A joint sheet alone does not show both turns. |
| MAN-08 | The corrected 110500 falls within OEM-03's 110301-and-above range. Retain v1 containing the earlier navigation and A/B/C verification notes. Keep the original unresolved decision valid for the original input; change the current note because the input changed. No causal explanation for the entry error is supplied. Verify changed content and reasoning in v2, not just a new name. |
| MAN-09 | Two design options, a reasoned selection, actual aid, actual reader selection/explanation, feedback and reasoned revision/retention. First target is OEM-05's engine identification section, PDF page 47; it is not the complete LeeBoy paver operating manual. Second target is OEM-02, contents on PDF page 4. Preserve prompts, errors and limitations in the observation. |

## Model verification note for MAN-04

**Manual selection — practice records A to C**

“Record A's AR13HA serial 110450 fits the 110301-and-above cover of OEM-03. Record B's AR13HAR serial 100850 fits OEM-04's 100901-and-below cover. Record C's serial 105500 matches neither supplied range. OEM-04's higher revision number and later date do not extend its serial scope. Please confirm C's complete machine record and obtain the applicable publication through the responsible instructor or manufacturer support. These are classroom cover matches; current machine configuration, information and authorization remain separate checks before actual work.”

This is one acceptable concise note. Do not require learners to reproduce its sentences. Preserve the difference between “matches the supplied cover” and “approved for actual work.”

## Criterion anchors and feedback

| Criterion | Observable evidence | Useful response when evidence is incomplete |
|---|---|---|
| Identify and match | Correct model, publication and serial scope, with page evidence | Compare the exact boundary words before asking for a fresh decision |
| Navigate and preserve | Actual file opened, passage found, authored note saved and reopened | Demonstrate one control with unrelated content, then return tool control |
| Calculate and interpret | Inclusive counts and units/meaning are correct; no machine-count inference | Use a three-page range to show why an endpoint counts |
| Communicate uncertainty | Clear match/unresolved status, retained limits and next action | Ask which sentence establishes the claimed approval or cause |
| Coordinate and adapt | Both checking roles observed; revision responds to corrected input | Record the missing turn or unchanged content, then arrange another attempt |
| Develop and test an aid | Two options, chosen aid, real test observation and limited conclusion | Separate a prediction from what the reader actually selected |

**Calibration:** Selecting OEM-04 for record C solely because “Revision 10 is newer” is Not yet demonstrated for matching. After the observer asks “What serial range does that cover name?”, a learner identifies the gap: record Demonstrated with support if the remaining criterion is met, quoting that prompt. A learner who uses enlarged text, compares the boundaries without a solving prompt and records the unresolved result can demonstrate the selection criterion independently. No cover reading or no opportunity is Not observed.

## A fresh retry

After teaching, use AR13HA practice serial **110700**, AR13HAR **100700**, and AR13HA **106000**. Keep the original answer model out of view. Expected cover matches are OEM-03, OEM-04 and neither, respectively. Change the requested navigation heading if the earlier page has been memorized. Do not describe these local tasks as validated parallel tests.

| Learning ID / date | |
|---|---|
| Selected activities and criteria | |
| Access tools / exact task-solving prompts | |
| Individual action and retained evidence | |
| Status for each criterion | |
| Feedback and fresh retry | |
| Actual technical/application question referred onward | |

Technical review of document applicability and classroom piloting remain separate from this authored answer check. Record those reviews only after they occur.
